Korean History Study Site - Deployment Instructions

1. Sign in to https://github.com/
2. Create a new public repository named: koreanhistory_umgj
3. Upload index.html from this folder to the repository's root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your URL will usually be:
   https://YOUR-GITHUB-USERNAME.github.io/koreanhistory_umgj/

Replace YOUR-GITHUB-USERNAME with your GitHub username.

Note: This repository and website are public if you choose a public repository.
The HTML file itself does not implement account login or password protection.
